        <div id="footer">
                       
            <p class="copyright">
                &copy; <?php echo date("Y"); ?> Mariomart, Inc.
            </p>
        </div>
    <!-- end page -->
    </body>
</html>