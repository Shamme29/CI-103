<div id="topBarDiv">
    <img id="topLogo" src="../../images/pageImages/Logo.png">
    <div id="logoText">MarioMart</div>
    <a id="logout" href="../../login.php">Log out </a>
    </div>

<div id="letUsBuyABookPage">

<div id="content">
<a id="backLink" href="../../buyer_page">Back</a>
    <!-- display product -->
    <?php include '../view/product.php'; ?>
</div>
<?php include '../../view/footer.php'; ?>
</div>
